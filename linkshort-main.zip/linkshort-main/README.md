# Linkshort - node js simple link redirector

This is vercel compatibilite web app to shortcut your links

## See links.json for configuration
```
{
  "/endpoint": "link"
}
```
